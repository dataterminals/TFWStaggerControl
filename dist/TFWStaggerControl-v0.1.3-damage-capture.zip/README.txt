TFWStaggerControl — DAMAGE-TYPE CAPTURE  (v0.1.3, 2026-07-24)
============================================================

Combat stagger is still fully OFF (unchanged). This build adds the piece we need
for SELECTIVE, per-damage-type control: it now reads the actual damage type of
each hit (melee vs bullet vs explosion, etc.) one step upstream and logs it. It
does NOT change behavior yet — everything is still suppressed — it just proves we
can see the type, so the next build can let you keep stagger for some types and
kill it for others.

  >> Replace any older TFWStaggerControl folder with this one.

WHAT TO DO
  Take a couple of MELEE hits and a couple of GUNFIRE/BULLET hits, a beat apart.
  (Explosions one-tap you, so don't worry about those.) Combat stagger should stay
  off the whole time. Then send the log.

WHAT WE'RE LOOKING FOR IN THE LOG  ([TFWStaggerControl])
    hooked ...BP_PlayerBase_C:ReceiveAnyDamage .. the new damage capture (after you load in)
    damage: type=BP_MeleeDamage_FW... family=melee    <-- the captured type, per hit
    hit-react: last_damage=... family=... selective_would_block=...
                                            <-- confirms the type lines up with the stagger
    SUPPRESS hit-react — cancelling ....... still stops it (blanket, for now)

WHAT IT IS  (unchanged)
  - Pure UE4SS Lua. No DLLs / pak / save edits. Delete folder = vanilla.
  - Single-player please. Nothing in any menu. Fall stagger unaffected (separate system).

REQUIREMENTS
  - The Forever Winter (build 24097213). RE-UE4SS v3.0.1 Beta (whatever loads your other Lua mods).

INSTALL
  1. ...\The Forever Winter\Windows\ForeverWinter\Binaries\Win64\ue4ss\Mods\   (or via MO2 + Root Builder)
  2. Copy the "TFWStaggerControl" folder from this zip into that Mods\ folder.
  3. Launch, load into a level, take some melee + gunfire.

PLEASE REPORT BACK to Deni with:
  1. Combat stagger stayed off? (yes / no)
  2. The UE4SS.log (the [TFWStaggerControl] lines — especially "damage:" and "hit-react:").
  3. Which hit types you took.

Thanks!
